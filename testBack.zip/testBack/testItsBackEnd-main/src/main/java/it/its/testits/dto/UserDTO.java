package it.its.testits.dto;


import it.its.testits.domain.Ruolo;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UserDTO {
	
	


	@NotNull
	int id;
	@NotNull
	@Size(min = 16,max = 16)
	String Cf;
	@NotNull
	String nome;
	@NotNull
	String iuser;
	@NotNull
	String password;
	@NotNull
	@Enumerated(EnumType.STRING)
	Ruolo ruolo;
	@NotNull
	String numtel;

	
	
	public UserDTO() {
		super();
	}
	public UserDTO(@NotNull int id, @NotNull String cf, @NotNull String nome, @NotNull String iuser,
			@NotNull String password, @NotNull @NotNull Ruolo ruolo, @NotNull String numtel) {
		this.id = id;
		Cf = cf;
		this.nome = nome;
		this.iuser = iuser;
		this.password = password;
		this.ruolo = ruolo;
		this.numtel = numtel;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCf() {
		return Cf;
	}
	public void setCf(String cf) {
		Cf = cf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getiUser() {
		return iuser;
	}
	public void setiUser(String iuser) {
		this.iuser = iuser;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	
	public Ruolo getRuolo() {
		return ruolo;
	}
	public void setRuolo(Ruolo ruolo) {
		this.ruolo = ruolo;
	}
	public String getNumtel() {
		return numtel;
	}
	public void setNumtel(String numtel) {
		this.numtel = numtel;
	}
	
	
}