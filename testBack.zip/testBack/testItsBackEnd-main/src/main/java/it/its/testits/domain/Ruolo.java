package it.its.testits.domain;

public enum Ruolo {
	DIPENDENTE,
	AMMINISTRATORE

}
