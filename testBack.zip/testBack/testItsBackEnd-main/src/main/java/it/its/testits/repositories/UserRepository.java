package it.its.testits.repositories;
import org.springframework.data.jpa.repository.JpaRepository;

import it.its.testits.domain.Utente;





public interface UserRepository  extends JpaRepository<Utente, Integer>{

	 Utente findByiuser(String iuser);

}
