package it.its.testits.utils;

import java.util.ArrayList;
import java.util.List;

import it.its.testits.domain.Utente;
import it.its.testits.dto.UserDTO;

public class Conversions {
	public static Utente userFromUserDto(UserDTO userDTO) {
		Utente user = new Utente();
		
		user.setId(userDTO.getId());
		user.setNome(userDTO.getNome());
		user.setCf(userDTO.getCf());
		user.setiUser(userDTO.getiUser());
		user.setRuolo(userDTO.getRuolo());
		user.setPassword(userDTO.getPassword());
		user.setNumtel(userDTO.getNumtel());
		
		return user;
	}
	
	public static UserDTO convertToDto(Utente user) {
        return new UserDTO(user.getId(),user.getCf(),user.getNome(), user.getiUser(),user.getPassword(),user.getRuolo(),  user.getNumtel());
    }
	
	public static List<UserDTO> userDtoListFromUserList(List<Utente> userList) {
		List<UserDTO> listUserDto = new ArrayList<UserDTO>();
		for (Utente user : userList) {
			listUserDto.add(convertToDto(user));
		}
		return listUserDto;
}

}
