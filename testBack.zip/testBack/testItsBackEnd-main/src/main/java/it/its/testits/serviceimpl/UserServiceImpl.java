package it.its.testits.serviceimpl;

import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import it.its.testits.domain.Utente;
import it.its.testits.dto.UserDTO;

import it.its.testits.repositories.UserRepository;
import it.its.testits.service.IUserService;
import it.its.testits.utils.Conversions;
@Service
public class UserServiceImpl implements IUserService{
	
	@Autowired
	UserRepository userRepository;
	
	@Override
	@Transactional
	public UserDTO save(UserDTO userDTO) {
		Utente user = Conversions.userFromUserDto(userDTO);
		Utente userSaved = userRepository.save(user);
		userDTO.setId(userSaved.getId());
		return userDTO;
	}
	
	@Override
	@Transactional
	public List<UserDTO> findAllUser() {
		return Conversions.userDtoListFromUserList(userRepository.findAll());
	}

	  @Override
	    public Utente login(String iuser, String password) {
		  Utente user = userRepository.findByiuser(iuser);
	        if (user != null && password.equals(user.getPassword())) {
	            return user;
	        } else {
	            return null;
	        }

	  }
}
