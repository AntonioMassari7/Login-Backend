package it.its.testits.domain;







import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;



@Entity
public class Utente {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	int id;
	
	String Cf;
	String nome;
	String iuser;
	String password;
	@Enumerated(EnumType.STRING)
	Ruolo ruolo;
	
	String numtel;
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCf() {
		return Cf;
	}
	public void setCf(String cf) {
		Cf = cf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getiUser() {
		return iuser;
	}
	public void setiUser(String iuser) {
		this.iuser = iuser;
	}
	public Utente() {
		super();
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public Ruolo getRuolo() {
		return ruolo;
	}
	public void setRuolo(Ruolo ruolo) {
		this.ruolo = ruolo;
	}
	
	public String getNumtel() {
		return numtel;
	}
	public void setNumtel(String numtel) {
		this.numtel = numtel;
	}
}