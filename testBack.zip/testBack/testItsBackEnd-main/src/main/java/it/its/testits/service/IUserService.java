package it.its.testits.service;

import java.util.List;

import it.its.testits.domain.Utente;
import it.its.testits.dto.UserDTO;
import it.its.testits.exceptions.UserNotFoundExceptions;

public interface IUserService {
	public UserDTO save (UserDTO userDTO) throws UserNotFoundExceptions;
	public List<UserDTO> findAllUser();
	Utente login(String iuser, String password);
	
	/*public UserDTO getLogin(String iuser, String password);*/
}
