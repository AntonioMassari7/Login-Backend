package it.its.testits.restocontrollers;

import java.io.Console;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.its.testits.domain.Utente;
import it.its.testits.dto.UserDTO;
import it.its.testits.exceptions.UserNotFoundExceptions;
import it.its.testits.service.IUserService;
import it.its.testits.utils.Conversions;

@RestController
@RequestMapping("/api/user")
public class UserRestController {

@Autowired
IUserService iUserService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO save(@RequestBody @Valid UserDTO userDto) throws UserNotFoundExceptions  {
		return iUserService.save(userDto);
	}
	
	@RequestMapping(value = "/findAllUser", method = RequestMethod.GET)
	public List<UserDTO> findAllProductor() {
		return iUserService.findAllUser();
	}


		@GetMapping("/login")
	    public ResponseEntity<UserDTO> login(@RequestParam("iuser") String iuser, @RequestParam("password") String password) {
			 Utente user = iUserService.login(iuser, password);
		        if (user != null) {
		            UserDTO userDto = Conversions.convertToDto(user);
		            return new ResponseEntity<>(userDto, HttpStatus.OK);
		        } else {
		        	
		            return new ResponseEntity<>( HttpStatus.UNAUTHORIZED);
		           
		        }
		    }
    }

